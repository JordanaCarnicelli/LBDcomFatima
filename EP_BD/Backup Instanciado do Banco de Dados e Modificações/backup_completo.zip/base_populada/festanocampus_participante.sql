-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: festanocampus
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.16-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `participante`
--

DROP TABLE IF EXISTS `participante`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `participante` (
  `cpf` varchar(25) NOT NULL,
  `nivel_escolaridade` varchar(75) NOT NULL,
  `ocupacao` varchar(75) NOT NULL,
  `isento_pagamento` char(1) NOT NULL,
  `id_onibus` int(11) DEFAULT NULL,
  `id_caravana` int(11) DEFAULT NULL,
  `SEM_BARRACA` int(11) DEFAULT NULL,
  `COM_BARRACA` int(11) DEFAULT NULL,
  PRIMARY KEY (`cpf`),
  UNIQUE KEY `FKPES_PAR_IND` (`cpf`),
  KEY `FKTRANSPORTA_IND` (`id_onibus`),
  KEY `FKPERTENCE_1_IND` (`id_caravana`),
  CONSTRAINT `FKPERTENCE_1_FK` FOREIGN KEY (`id_caravana`) REFERENCES `caravana` (`id_caravana`),
  CONSTRAINT `FKPES_PAR_FK` FOREIGN KEY (`cpf`) REFERENCES `pessoa_fisica` (`cpf`),
  CONSTRAINT `FKTRANSPORTA_FK` FOREIGN KEY (`id_onibus`) REFERENCES `onibus` (`id_onibus`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `participante`
--

LOCK TABLES `participante` WRITE;
/*!40000 ALTER TABLE `participante` DISABLE KEYS */;
INSERT INTO `participante` VALUES ('24984164000','Ensino Médio','Estudante','0',NULL,NULL,1,0),('24984164111','Ensino Fuldamental','Estudante','0',5,5,0,1),('24984164222','Ensino Médio','Estudante','1',1,1,0,1),('24984164333','Ensino Superior','Programador','0',NULL,NULL,0,1),('24984164444','Ensino Superior','Ensino Superior','0',3,3,0,1),('24984164555','Ensino Superior','Professor','0',NULL,NULL,0,1),('24984164666','Ensino Superior','Arquiteto','0',NULL,NULL,1,0),('24984164777','Ensino Superior','Engenheiro Civil','1',2,2,1,0),('24984164888','Ensino Superior','Médico','0',NULL,NULL,1,0),('24984164999','Ensino Superior','Empresário','0',4,4,1,0);
/*!40000 ALTER TABLE `participante` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-11-21 16:30:45
