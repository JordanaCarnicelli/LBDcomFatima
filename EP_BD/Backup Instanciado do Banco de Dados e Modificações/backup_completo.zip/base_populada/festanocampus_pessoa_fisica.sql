-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: festanocampus
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.16-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `pessoa_fisica`
--

DROP TABLE IF EXISTS `pessoa_fisica`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pessoa_fisica` (
  `cpf` varchar(25) NOT NULL,
  `nome` varchar(75) NOT NULL,
  `data_nasc` date NOT NULL,
  `idade` int(11) DEFAULT NULL,
  `end_rua` varchar(75) NOT NULL,
  `end_num` int(11) NOT NULL,
  `end_bairro` varchar(75) NOT NULL,
  `end_cidade` varchar(75) NOT NULL,
  `end_cep` varchar(16) NOT NULL,
  `email` varchar(75) NOT NULL,
  `genero` varchar(75) NOT NULL,
  `PARTICIPANTE` int(11) DEFAULT NULL,
  `ISENTO` int(11) DEFAULT NULL,
  `FUNCIONARIO` int(11) DEFAULT NULL,
  PRIMARY KEY (`cpf`),
  UNIQUE KEY `ID_PESSOA_FISICA_IND` (`cpf`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pessoa_fisica`
--

LOCK TABLES `pessoa_fisica` WRITE;
/*!40000 ALTER TABLE `pessoa_fisica` DISABLE KEYS */;
INSERT INTO `pessoa_fisica` VALUES ('10641897111','André Garcia','1990-07-20',NULL,'R. Jorge Americo',392,'Alto da Lapa','São Paulo','5083130','10641897111@gmail.com','Masculino',0,1,0),('10641897222','Mario Antonio','1986-08-30',NULL,'R. Cardeal Arcoverde',569,'Pinheiros','São Paulo','5407002','10641897222@gmail.com','Masculino',0,1,0),('10641897333','Roberto Faria','1987-05-26',NULL,'R. Joaquim Macedo',414,'Jardim Guedala','São Paulo','5605020','10641897333@gmail.com','Masculino',0,1,0),('10641897444','Maria Clara Nunes','1988-06-12',NULL,'R. Cabedelo',245,'Vila Inah','São Paulo','5512300','10641897444@gmail.com','Feminino',0,1,0),('10641897555','Leticia Antunes','1975-05-28',NULL,'R. Francisco Ferrari',423,'Parque Continental','São Paulo','5328020','10641897555@gmail.com','Feminino',0,1,0),('14535715555','Brenda Lima Barbosa','1964-11-11',NULL,'R. Conselheiro Moreira de Barros',875,'Cachoeirinha','Diadema','2493395','14535715555@gmail.com','Feminino',0,0,1),('14535869111','Vinícius Almeida Pinto','1952-02-04',NULL,'R. da Consolação',245,'Campo Grande','Santo André','5643046','14535869111@gmail.com','Masculino',0,1,0),('14864586111','Felipe Cunha Pereira','1979-12-01',NULL,'R. Três Rios',816,'Centro','Guarulhos','7273202','14864586111@gmail.com','Masculino',0,1,0),('14864586222','Arthur Pinto Pereira','1990-11-02',NULL,'R. Sete de Abril (São Paulo)',972,'Parelheiros','Guarulhos','9873021','14864586222@gmail.com','Masculino',0,1,0),('14864586333','Vitória Pereira Silva','2000-02-20',NULL,'R. 15 de Novembro (São Paulo)',796,'Pari','Guarulhos','5680329','14864586333@gmail.com','Feminino',0,1,0),('14864586444','Gabriela Sousa Cardoso','2003-10-23',NULL,'R. 25 de Março',359,'Parque do Carmo','Osasco','8648353','14864586444@gmail.com','Feminino',0,1,0),('14864586555','Manuela Rodrigues Cardoso','1980-07-27',NULL,'R. Líbero Badaró',408,'Penha?','São Bernardo do Campo','8769165','14864586555@gmail.com','Feminino',0,1,0),('14868895111','Nicole Oliveira Souza','1963-03-17',NULL,'R. Maria Antônia',359,'Vila Inah','São Paulo','5512300','14868895111@gmail.com','Feminino',0,1,0),('14868895222','Isabelle Rocha Pinto','1986-08-30',NULL,'Al. Ministro Rocha Azevedo',408,'Parque Continental','São Paulo','5328020','14868895222@gmail.com','Feminino',0,1,0),('14868895333','Pedro Sousa Almeida','1987-05-26',NULL,'R. da Consolação',463,'Bela Vista','São Paulo','1323030','14868895333@gmail.com','Masculino',0,1,0),('14868895444','Tomás Lima Barbosa','1988-06-12',NULL,'R. Padre João Manuel',621,'Centro','Guarulhos','7273202','14868895444@gmail.com','Masculino',0,1,0),('14868895555','Isabela Castro Rodrigues','1975-05-28',NULL,'R. Paulistânia',691,'Parelheiros','Guarulhos','9873021','14868895555@gmail.com','Feminino',0,1,0),('15975614333','Beatriz Silva Alves','1951-01-17',NULL,'R. Conde de Sarzedas',852,'Pinheiros','São Paulo','5407002','15975614333@gmail.com','Feminino',0,0,1),('15998714111','Matheus Costa Barbosa','1980-07-27',NULL,'R. José Gianasi',350,'Bela Vista','São Paulo','1323030','15998714111@gmail.com','Masculino',0,0,1),('15998714222','Mateus Gomes Araujo','1957-01-13',NULL,'P. Cássia Clay',706,'Centro','Guarulhos','7273202','15998714222@gmail.com','Masculino',0,0,1),('15998714333','Arthur Fernandes Pereira','1972-01-30',NULL,'R. Pedroso Alvarenga',959,'Parelheiros','Guarulhos','9873021','15998714333@gmail.com','Masculino',0,0,1),('15998714444','Renan Rocha Araujo','1950-12-21',NULL,'R. Peixoto Gomide',831,'Pari','Guarulhos','5680329','15998714444@gmail.com','Masculino',0,0,1),('15998714555','Erick Costa Gomes','1971-02-28',NULL,'Av. Conde Francisco Matarazzo',274,'Parque do Carmo','Osasco','8648353','15998714555@gmail.com','Masculino',0,0,1),('16548739222','Kauê Pereira Souza','1951-01-17',NULL,'R. Leite de Morais',423,'Campo Limpo','São Caetano do Sul','1756548','16548739222@gmail.com','Masculino',0,1,0),('21554826111','Alex Rocha Almeida','1950-11-09',NULL,'R. Capitão Manuel Novais',835,'Penha?','São Bernardo do Campo','8769165','21554826111@gmail.com','Masculino',0,0,1),('24984164000','Jandira Arruda','2003-10-23',NULL,'R. Francisco Ferrari',412,'Parque Continental','São Paulo','5328020','24984164000@gmail.com','Feminino',1,0,0),('24984164111','Anderson Kistner','1989-04-11',NULL,'R. Jorge Americo',138,'Alto da Lapa','São Paulo','5083130','24984164111@gmail.com','Masculino',1,0,0),('24984164222','Luana Solimeno','1985-01-05',NULL,'R. Cardeal Arcoverde',22,'Pinheiros','São Paulo','5407002','24984164222@gmail.com','Feminino',1,0,0),('24984164333','Alexander Kistner','1988-03-06',NULL,'R. Joaquim Macedo',237,'Jardim Guedala','São Paulo','5605020','24984164333@gmail.com','Masculino',1,0,0),('24984164444','Jordana Carnicelli','1975-05-02',NULL,'R. Cabedelo',202,'Vila Inah','São Paulo','5512300','24984164444@gmail.com','Feminino',1,0,0),('24984164555','Daniel Pinheiro','1992-06-24',NULL,'R. Francisco Ferrari',850,'Parque Continental','São Paulo','5328020','24984164555@gmail.com','Masculino',1,0,0),('24984164666','Laura Pinheiro','1984-03-03',NULL,'R. Jorge Americo',889,'Alto da Lapa','São Paulo','5083130','24984164666@gmail.com','Feminino',1,0,0),('24984164777','José de Oliveira','1979-12-01',NULL,'R. Cardeal Arcoverde',289,'Pinheiros','São Paulo','5407002','24984164777@gmail.com','Masculino',1,0,0),('24984164888','Antonio Carlos','1990-11-02',NULL,'R. Joaquim Macedo',36,'Jardim Guedala','São Paulo','5605020','24984164888@gmail.com','Masculino',1,0,0),('24984164999','Fernando Martins','2000-02-20',NULL,'R. Cabedelo',293,'Vila Inah','São Paulo','5512300','24984164999@gmail.com','Masculino',1,0,0),('31286584444','Julia Araujo Melo','1964-11-11',NULL,'R. Maria Antônia',972,'Pinheiros','São Paulo','5407002','31286584444@gmail.com','Feminino',0,1,0),('35798784444','Gabriela Martins Souza','1973-02-26',NULL,'R. Conselheiro Furtado',668,'Ponte Rasa','Diadema','5440743','35798784444@gmail.com','Feminino',0,0,1),('41684194111','Júlia Gomes Correia','1957-01-13',NULL,'R. Alfredo Pujol',463,'Perdizes?','Osasco','6364050','41684194111@gmail.com','Feminino',0,1,0),('41684194222','Leonor Correia Rodrigues','1972-01-30',NULL,'R. Amaral Gama',621,'Pinheiros','São Paulo','5407002','41684194222@gmail.com','Feminino',0,1,0),('41684194333','Camila Correia Dias','1950-12-21',NULL,'R. Augusta (São Paulo)',691,'Ponte Rasa','Diadema','5440743','41684194333@gmail.com','Feminino',0,1,0),('41684194444','Cauã Cavalcanti Ribeiro','1971-02-28',NULL,'R. Augusto Tolle',392,'Cachoeirinha','Diadema','2493395','41684194444@gmail.com','Masculino',0,1,0),('41684194555','Antônio Silva Lima','1950-11-09',NULL,'Al. Joaquim Eugênio de Lima',569,'Cambuci?','Diadema','6411248','41684194555@gmail.com','Masculino',0,1,0),('41684194666','Sarajones Marques Peres','1996-11-01',NULL,'R. José Paulino',414,'Campo Belo','Santo André','6904684','41684194666@gmail.com','Feminino',0,1,0),('45612378222','Paulo Cunha Barros','1952-02-04',NULL,'R. Cardeal Arcoverde',274,'Perdizes?','Osasco','6364050','45612378222@gmail.com','Masculino',0,0,1),('65498731555','Ryan Santos Cardoso','1998-09-06',NULL,'R. Maranhão',796,'Jardim Guedala','São Paulo','5605020','65498731555@gmail.com','Masculino',0,1,0),('76150293111','Gabrielle Santos Almeida','1998-09-06',NULL,'R. Conselheiro Saraiva',921,'Cambuci?','Diadema','6411248','76150293111@gmail.com','Feminino',0,0,1),('76150293222','Leila Gomes Cunha','1963-03-17',NULL,'R. da Consolação',321,'Campo Belo','Santo André','6904684','76150293222@gmail.com','Feminino',0,0,1),('76150293333','Beatriz Cavalcanti Silva','1964-05-25',NULL,'R. Padre João Manuel',753,'Campo Grande','Santo André','5643046','76150293333@gmail.com','Feminino',0,0,1),('76150293444','Matilde Rodrigues Pereira','1990-07-18',NULL,'R. Paulistânia',951,'Campo Limpo','São Caetano do Sul','1756548','76150293444@gmail.com','Feminino',0,0,1),('76150293555','Manuela Azevedo Sousa','1993-09-02',NULL,'R. Pedro Doll',852,'Penha?','São Bernardo do Campo','8769165','76150293555@gmail.com','Feminino',0,0,1),('86431275333','Ana Correia Melo','1973-02-26',NULL,'R. Líbero Badaró',816,'Penha?','São Bernardo do Campo','8769165','86431275333@gmail.com','Feminino',0,1,0);
/*!40000 ALTER TABLE `pessoa_fisica` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-11-21 16:30:42
