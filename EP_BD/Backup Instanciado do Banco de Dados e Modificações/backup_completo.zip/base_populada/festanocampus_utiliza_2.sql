-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: festanocampus
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.16-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `utiliza_2`
--

DROP TABLE IF EXISTS `utiliza_2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `utiliza_2` (
  `id_atividade` int(11) NOT NULL,
  `url` varchar(75) NOT NULL,
  PRIMARY KEY (`url`,`id_atividade`),
  UNIQUE KEY `ID_UTILIZA_2_IND` (`url`,`id_atividade`),
  KEY `FKUTI_VIR_IND` (`id_atividade`),
  CONSTRAINT `FKUTI_AMB` FOREIGN KEY (`url`) REFERENCES `ambiente` (`url`),
  CONSTRAINT `FKUTI_VIR_FK` FOREIGN KEY (`id_atividade`) REFERENCES `_virtual` (`id_atividade`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `utiliza_2`
--

LOCK TABLES `utiliza_2` WRITE;
/*!40000 ALTER TABLE `utiliza_2` DISABLE KEYS */;
INSERT INTO `utiliza_2` VALUES (20,'https://twitter.com/ccxpoficial'),(17,'www.campusparty.com'),(16,'www.campusparty.forum.com'),(18,'www.facebook/CPOfficial'),(19,'www.instagram.com/cpofficial');
/*!40000 ALTER TABLE `utiliza_2` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-11-21 16:30:37
