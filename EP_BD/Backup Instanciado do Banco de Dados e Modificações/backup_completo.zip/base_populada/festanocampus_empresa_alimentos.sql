-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: festanocampus
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.16-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `empresa_alimentos`
--

DROP TABLE IF EXISTS `empresa_alimentos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `empresa_alimentos` (
  `cnpj` varchar(30) NOT NULL,
  `id_espaco_fisico` int(11) DEFAULT NULL,
  `alvara` varchar(75) NOT NULL,
  `cod_setor` int(11) NOT NULL,
  PRIMARY KEY (`cnpj`),
  UNIQUE KEY `FKPES_EMP_1_IND` (`cnpj`),
  UNIQUE KEY `FKOCUPA_3_ID` (`id_espaco_fisico`),
  UNIQUE KEY `FKOCUPA_3_IND` (`id_espaco_fisico`),
  KEY `FKPROSPECTA_2_IND` (`cod_setor`),
  CONSTRAINT `FKOCUPA_3_FK` FOREIGN KEY (`id_espaco_fisico`) REFERENCES `espaco_fisico` (`id_espaco_fisico`),
  CONSTRAINT `FKPES_EMP_1_FK` FOREIGN KEY (`cnpj`) REFERENCES `pessoa_juridica` (`cnpj`),
  CONSTRAINT `FKPROSPECTA_2_FK` FOREIGN KEY (`cod_setor`) REFERENCES `marketing` (`cod_setor`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empresa_alimentos`
--

LOCK TABLES `empresa_alimentos` WRITE;
/*!40000 ALTER TABLE `empresa_alimentos` DISABLE KEYS */;
INSERT INTO `empresa_alimentos` VALUES ('1222782878655',30,'C:UsersAndersonDesktopBDcomSarinhaAlvara1222782878655',3),('2426270765011',26,'C:UsersAndersonDesktopBDcomSarinhaAlvara2426270765011',3),('3262144721244',29,'C:UsersAndersonDesktopBDcomSarinhaAlvara3262144721244',3),('7318458635733',28,'C:UsersAndersonDesktopBDcomSarinhaAlvara7318458635733',3),('7963854505822',27,'C:UsersAndersonDesktopBDcomSarinhaAlvara7963854505822',3);
/*!40000 ALTER TABLE `empresa_alimentos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-11-21 16:30:54
