-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: festanocampus
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.16-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `pessoa_juridica`
--

DROP TABLE IF EXISTS `pessoa_juridica`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pessoa_juridica` (
  `cnpj` varchar(30) NOT NULL,
  `cnae` int(11) NOT NULL,
  `nome_fantasia` varchar(75) NOT NULL,
  `razao_social` varchar(75) NOT NULL,
  `contrato` varchar(75) NOT NULL,
  `VEICULO_COMUNICACAO` int(11) DEFAULT NULL,
  `PATROCINADOR` int(11) DEFAULT NULL,
  `FORNECEDOR` int(11) DEFAULT NULL,
  `EMPRESA_ALIMENTOS` int(11) DEFAULT NULL,
  `EMPRESA_VAREJO` int(11) DEFAULT NULL,
  PRIMARY KEY (`cnpj`),
  UNIQUE KEY `ID_PESSOA_JURIDICA_IND` (`cnpj`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pessoa_juridica`
--

LOCK TABLES `pessoa_juridica` WRITE;
/*!40000 ALTER TABLE `pessoa_juridica` DISABLE KEYS */;
INSERT INTO `pessoa_juridica` VALUES ('1222782878655',56201,'Subway','Razão Social Subway','C:UsersAndersonDesktopBDcomSarinhaContratos1222782878655',0,0,0,1,0),('1482115672555',47296,'Galápagos','Razão Social Galápagos','C:UsersAndersonDesktopBDcomSarinhaContratos1482115672555',0,0,0,0,1),('2426270765011',56201,'Spoleto','Razão Social Spoleto','C:UsersAndersonDesktopBDcomSarinhaContratos2426270765011',0,0,0,1,0),('3185860265111',47296,'Chilli Beans','Razão Social Chilli Beans','C:UsersAndersonDesktopBDcomSarinhaContratos3185860265111',0,0,0,0,1),('3259265956543',81290,'RS Serviços','Razão Social RS Serviços','C:UsersAndersonDesktopBDcomSarinhaContratos3259265956543',0,0,1,0,0),('3262144721244',56201,'Black Dog','Razão Social Black Dog','C:UsersAndersonDesktopBDcomSarinhaContratos3262144721244',0,0,0,1,0),('4176846871111',62023,'Apple','Razão Social Apple','C:UsersAndersonDesktopBDcomSarinhaContratos4176846871111',0,1,0,0,0),('4176846871222',62023,'Microsoft','Razão Social Microsoft','C:UsersAndersonDesktopBDcomSarinhaContratos4176846871222',0,1,0,0,0),('4176846871333',45687,'Nvidia','Razão Social Nvidia','C:UsersAndersonDesktopBDcomSarinhaContratos4176846871333',0,1,0,0,0),('4176846871444',98765,'Intel','Razão Social Intel','C:UsersAndersonDesktopBDcomSarinhaContratos4176846871444',0,1,0,0,0),('4176846871555',62023,'IBM','Razão Social IBM','C:UsersAndersonDesktopBDcomSarinhaContratos4176846871555',0,1,0,0,0),('5047119538993',82300,'Perfecta Eventos','Razão Social Perfecta Eventos','C:UsersAndersonDesktopBDcomSarinhaContratos5047119538993',0,0,1,0,0),('5196586873111',90027,'Folha de São Paulo','Razão Social Folha de São Paulo','C:UsersAndersonDesktopBDcomSarinhaContratos5196586873111',1,0,0,0,0),('5196586873222',90027,'Globo','Razão Social Globo','C:UsersAndersonDesktopBDcomSarinhaContratos5196586873222',1,0,0,0,0),('5196586873333',90027,'Jovem Nerd','Razão Social Jovem Nerd','C:UsersAndersonDesktopBDcomSarinhaContratos5196586873333',1,0,0,0,0),('5196586873444',90027,'Jovem Pan','Razão Social Jovem Pan','C:UsersAndersonDesktopBDcomSarinhaContratos5196586873444',1,0,0,0,0),('5196586873555',90027,'Não Salvo','Razão Social Não Salvo','C:UsersAndersonDesktopBDcomSarinhaContratos5196586873555',1,0,0,0,0),('6191831709652',80111,'Albatroz Segurança','Razão Social Albatroz Segurança','C:UsersAndersonDesktopBDcomSarinhaContratos6191831709652',0,0,1,0,0),('6325255392663',59120,'Focus Audiovisual','Razão Social Focus Audiovisual','C:UsersAndersonDesktopBDcomSarinhaContratos6325255392663',0,0,1,0,0),('7203236580222',47296,'Nerd Store','Razão Social Nerd Store','C:UsersAndersonDesktopBDcomSarinhaContratos7203236580222',0,0,0,0,1),('7318458635733',56201,'Domino\'s','Razão Social Domino\'s','C:UsersAndersonDesktopBDcomSarinhaContratos7318458635733',0,0,0,1,0),('7963854505822',56201,'Casa do Pão de Queijo','Razão Social Casa do Pão de Queijo','C:UsersAndersonDesktopBDcomSarinhaContratos7963854505822',0,0,0,1,0),('9050752685444',47296,'Imaginarium','Razão Social Imaginarium','C:UsersAndersonDesktopBDcomSarinhaContratos9050752685444',0,0,0,0,1),('9199421953290',47512,'RSI Informática','Razão Social RSI Informática','C:UsersAndersonDesktopBDcomSarinhaContratos9199421953290',0,0,1,0,0),('9504818811333',47296,'Robocore','Razão Social Robocore','C:UsersAndersonDesktopBDcomSarinhaContratos9504818811333',0,0,0,0,1);
/*!40000 ALTER TABLE `pessoa_juridica` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-11-21 16:30:46
