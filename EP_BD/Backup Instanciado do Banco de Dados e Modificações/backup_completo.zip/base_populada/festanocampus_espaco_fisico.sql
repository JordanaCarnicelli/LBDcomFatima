-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: festanocampus
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.16-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `espaco_fisico`
--

DROP TABLE IF EXISTS `espaco_fisico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `espaco_fisico` (
  `id_espaco_fisico` int(11) NOT NULL,
  `dimensao` float NOT NULL,
  `localizacao` varchar(75) NOT NULL,
  `descricao` varchar(75) NOT NULL,
  `status` char(1) NOT NULL,
  `cod_setor` int(11) NOT NULL,
  `end_rua` varchar(75) NOT NULL,
  `end_num` int(11) NOT NULL,
  `end_bairro` varchar(75) NOT NULL,
  `end_cidade` varchar(75) NOT NULL,
  `end_cep` varchar(16) NOT NULL,
  PRIMARY KEY (`id_espaco_fisico`),
  UNIQUE KEY `SID_ESPACO_FISICO_ID` (`localizacao`),
  UNIQUE KEY `ID_ESPACO_FISICO_IND` (`id_espaco_fisico`),
  UNIQUE KEY `SID_ESPACO_FISICO_IND` (`localizacao`),
  KEY `FKORGANIZA_1_IND` (`cod_setor`),
  KEY `FKCOMPOE_1_IND` (`end_rua`,`end_num`,`end_bairro`,`end_cidade`,`end_cep`),
  CONSTRAINT `FKCOMPOE_1_FK` FOREIGN KEY (`end_rua`, `end_num`, `end_bairro`, `end_cidade`, `end_cep`) REFERENCES `area_total` (`end_rua`, `end_num`, `end_bairro`, `end_cidade`, `end_cep`),
  CONSTRAINT `FKORGANIZA_1_FK` FOREIGN KEY (`cod_setor`) REFERENCES `infraestrutura` (`cod_setor`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `espaco_fisico`
--

LOCK TABLES `espaco_fisico` WRITE;
/*!40000 ALTER TABLE `espaco_fisico` DISABLE KEYS */;
INSERT INTO `espaco_fisico` VALUES (1,9,'Descrição da localização 1','Espaço para atividades.','1',4,'R. Gumercindo Saraiva',54,'Pinheiros','São Paulo','1449070'),(2,9,'Descrição da localização 2','Espaço para atividades.','1',4,'R. Gumercindo Saraiva',54,'Pinheiros','São Paulo','1449070'),(3,9,'Descrição da localização 3','Espaço para atividades.','0',4,'R. Gumercindo Saraiva',54,'Pinheiros','São Paulo','1449070'),(4,9,'Descrição da localização 4','Espaço para atividades.','1',4,'R. Gumercindo Saraiva',54,'Pinheiros','São Paulo','1449070'),(5,9,'Descrição da localização 5','Espaço para atividades.','0',4,'R. Gumercindo Saraiva',54,'Pinheiros','São Paulo','1449070'),(6,12,'Descrição da localização 6','Espaço para atividades.','0',4,'R. Gumercindo Saraiva',54,'Pinheiros','São Paulo','1449070'),(7,12,'Descrição da localização 7','Espaço para atividades.','0',4,'R. Gumercindo Saraiva',54,'Pinheiros','São Paulo','1449070'),(8,12,'Descrição da localização 8','Espaço para atividades.','0',4,'R. Gumercindo Saraiva',54,'Pinheiros','São Paulo','1449070'),(9,12,'Descrição da localização 9','Espaço para atividades.','1',4,'R. Gumercindo Saraiva',54,'Pinheiros','São Paulo','1449070'),(10,12,'Descrição da localização 10','Espaço para atividades.','1',4,'R. Gumercindo Saraiva',54,'Pinheiros','São Paulo','1449070'),(11,9,'Descrição da localização 11','Espaço para lojas de varejo.','1',4,'R. Gumercindo Saraiva',54,'Pinheiros','São Paulo','1449070'),(12,9,'Descrição da localização 12','Espaço para lojas de varejo.','0',4,'R. Gumercindo Saraiva',54,'Pinheiros','São Paulo','1449070'),(13,9,'Descrição da localização 13','Espaço para lojas de varejo.','1',4,'R. Gumercindo Saraiva',54,'Pinheiros','São Paulo','1449070'),(14,9,'Descrição da localização 14','Espaço para lojas de varejo.','0',4,'R. Gumercindo Saraiva',54,'Pinheiros','São Paulo','1449070'),(15,9,'Descrição da localização 15','Espaço para lojas de varejo.','0',4,'R. Gumercindo Saraiva',54,'Pinheiros','São Paulo','1449070'),(16,15,'Descrição da localização 16','Espaço de estacionamento de onibus.','1',4,'R. Gumercindo Saraiva',54,'Pinheiros','São Paulo','1449070'),(17,15,'Descrição da localização 17','Espaço de estacionamento de onibus.','1',4,'R. Gumercindo Saraiva',54,'Pinheiros','São Paulo','1449070'),(18,15,'Descrição da localização 18','Espaço de estacionamento de onibus.','1',4,'R. Gumercindo Saraiva',54,'Pinheiros','São Paulo','1449070'),(19,15,'Descrição da localização 19','Espaço de estacionamento de onibus.','0',4,'R. Gumercindo Saraiva',54,'Pinheiros','São Paulo','1449070'),(20,15,'Descrição da localização 20','Espaço de estacionamento de onibus.','0',4,'R. Gumercindo Saraiva',54,'Pinheiros','São Paulo','1449070'),(21,4,'Descrição da localização 21','Espaço para barracas.','1',4,'R. Gumercindo Saraiva',54,'Pinheiros','São Paulo','1449070'),(22,4,'Descrição da localização 22','Espaço para barracas.','1',4,'R. Gumercindo Saraiva',54,'Pinheiros','São Paulo','1449070'),(23,4,'Descrição da localização 23','Espaço para barracas.','1',4,'R. Gumercindo Saraiva',54,'Pinheiros','São Paulo','1449070'),(24,4,'Descrição da localização 24','Espaço para barracas.','0',4,'R. Gumercindo Saraiva',54,'Pinheiros','São Paulo','1449070'),(25,4,'Descrição da localização 25','Espaço para barracas.','1',4,'R. Gumercindo Saraiva',54,'Pinheiros','São Paulo','1449070'),(26,9,'Descrição da localização 26','Espaço para empresas de alimentos.','1',4,'R. Gumercindo Saraiva',54,'Pinheiros','São Paulo','1449070'),(27,9,'Descrição da localização 27','Espaço para empresas de alimentos.','1',4,'R. Gumercindo Saraiva',54,'Pinheiros','São Paulo','1449070'),(28,9,'Descrição da localização 28','Espaço para empresas de alimentos.','0',4,'R. Gumercindo Saraiva',54,'Pinheiros','São Paulo','1449070'),(29,9,'Descrição da localização 29','Espaço para empresas de alimentos.','0',4,'R. Gumercindo Saraiva',54,'Pinheiros','São Paulo','1449070'),(30,9,'Descrição da localização 30','Espaço para empresas de alimentos.','1',4,'R. Gumercindo Saraiva',54,'Pinheiros','São Paulo','1449070'),(31,6,'Descrição da localização 31','Espaço de estacionamento de caros.','1',4,'R. Gumercindo Saraiva',54,'Pinheiros','São Paulo','1449070'),(32,6,'Descrição da localização 32','Espaço de estacionamento de caros.','1',4,'R. Gumercindo Saraiva',54,'Pinheiros','São Paulo','1449070'),(33,6,'Descrição da localização 33','Espaço de estacionamento de caros.','1',4,'R. Gumercindo Saraiva',54,'Pinheiros','São Paulo','1449070'),(34,6,'Descrição da localização 34','Espaço de estacionamento de caros.','0',4,'R. Gumercindo Saraiva',54,'Pinheiros','São Paulo','1449070'),(35,6,'Descrição da localização 35','Espaço de estacionamento de caros.','1',4,'R. Gumercindo Saraiva',54,'Pinheiros','São Paulo','1449070'),(36,9,'Descrição da localização 36','Espaço para lojas de varejo.','0',4,'R. Gumercindo Saraiva',54,'Pinheiros','São Paulo','1449070'),(37,4,'Descrição da localização 37','Espaço para barracas.','',4,'R. Gumercindo Saraiva',54,'Pinheiros','São Paulo','1449070'),(38,4,'Descrição da localização 38','Espaço para barracas.','',4,'R. Gumercindo Saraiva',54,'Pinheiros','São Paulo','1449070'),(39,4,'Descrição da localização 39','Espaço para barracas.','',4,'R. Gumercindo Saraiva',54,'Pinheiros','São Paulo','1449070'),(40,4,'Descrição da localização 40','Espaço para barracas.','',4,'R. Gumercindo Saraiva',54,'Pinheiros','São Paulo','1449070'),(41,4,'Descrição da localização 41','Espaço para barracas.','',4,'R. Gumercindo Saraiva',54,'Pinheiros','São Paulo','1449070');
/*!40000 ALTER TABLE `espaco_fisico` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-11-21 16:30:37
