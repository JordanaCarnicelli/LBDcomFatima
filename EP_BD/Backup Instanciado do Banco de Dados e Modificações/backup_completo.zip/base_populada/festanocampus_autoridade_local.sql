-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: festanocampus
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.16-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `autoridade_local`
--

DROP TABLE IF EXISTS `autoridade_local`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `autoridade_local` (
  `id_autoridade_local` int(11) NOT NULL,
  `nome_orgao` varchar(75) NOT NULL,
  `autoridade_destino` varchar(75) NOT NULL,
  `end_rua` varchar(75) NOT NULL,
  `end_num` int(11) NOT NULL,
  `end_bairro` varchar(75) NOT NULL,
  `end_cidade` varchar(75) NOT NULL,
  `end_cep` varchar(16) NOT NULL,
  `nome_representante` varchar(75) NOT NULL,
  `email_representante` varchar(75) NOT NULL,
  PRIMARY KEY (`id_autoridade_local`),
  UNIQUE KEY `SID_AUTORIDADE_LOCAL_ID` (`nome_orgao`),
  UNIQUE KEY `FKRECEBE_3_ID` (`autoridade_destino`),
  UNIQUE KEY `ID_AUTORIDADE_LOCAL_IND` (`id_autoridade_local`),
  UNIQUE KEY `SID_AUTORIDADE_LOCAL_IND` (`nome_orgao`),
  UNIQUE KEY `FKRECEBE_3_IND` (`autoridade_destino`),
  CONSTRAINT `FKRECEBE_3_FK` FOREIGN KEY (`autoridade_destino`) REFERENCES `relatorio_oficial` (`autoridade_destino`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `autoridade_local`
--

LOCK TABLES `autoridade_local` WRITE;
/*!40000 ALTER TABLE `autoridade_local` DISABLE KEYS */;
INSERT INTO `autoridade_local` VALUES (1,'Polícia Militar','Delegado de Polícia Militar','R. Sergipe',428,'Consolação','São Paulo','2550000','Isildur Filho de Elendil','isildur@ig.com'),(2,'Prefeitura Municipal','Prefeito do Município','Av. Mandaqui',197,'Limão','São Paulo','2550000','Gollum Doriana','gollum@ig.com'),(3,'Vigilância Sanitária','Diretor-Presidente da Vigilância Sanitária','Av. Dr. Arnaldo',351,'Consolação','São Paulo','1255000','Gamil Zirak','zirak@ig.com'),(4,'Polícia Civil','Delegado de Polícia Civil','Av. Zaki Narchi',751,'Carandiru','São Paulo','2029000','Fingolfin Filho de Finwe','fingolfin@ig.com'),(5,'Conselho Universitário','Reitor da Universidade','R. da Reitoria',374,'Butantã','São Paulo','3178200','Faramir Filho de Denethor','faramir@usp.br');
/*!40000 ALTER TABLE `autoridade_local` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-11-21 16:30:48
