use festanocampus;

-- gatilho da idade
delimiter |
create trigger insert_pf
before insert on pessoa_fisica
for each row
begin
	declare idade_calculada int(11);
    select timestampdiff(YEAR, NEW.data_nasc, CURDATE()) into idade_calculada;
    set new.data_nasc = idade_calculada;
end; | 

delimiter |
create trigger update_pf
before update on pessoa_fisica
for each row
begin
	declare idade_calculada int(11);
    select timestampdiff(YEAR, NEW.data_nasc, CURDATE()) into idade_calculada;
    set new.data_nasc = idade_calculada;
end; | 

-- n_funcionarios na tabela setor
delimiter |
create trigger insert_funcionario
after insert on funcionario
for each row
begin
	declare qtde_funcionario int(11);
    select count(*) from funcionario where cod_setor = NEW.cod_setor into qtde_funcionario;
    update setor set n_funcionarios = qtde_funcionario where cod_setor = NEW.cod_setor;
end;
|

delimiter |
create trigger update_funcionario
after update on funcionario
for each row
begin
	declare qtde_funcionario int(11);
    select count(*) from funcionario where cod_setor = NEW.cod_setor into qtde_funcionario;
    update setor set n_funcionarios = qtde_funcionario where cod_setor = NEW.cod_setor;
end;
|

-- montante_caixa na tabela contabilidade
-- obs o trigger abaixo deve ser implementado para todas as inserções
-- e atualizações nas tabelas que somam e subtraem do montante
delimiter |
create trigger montante_update
after update on compoe_2
for each row
begin
	declare montante float;
    -- valores que somam
    declare compoe2_soma float;
    declare compoe3_soma float;
    declare compoe4_soma float;
    declare compoe5_soma float;
    declare compoe6_soma float;
    -- valores que subtraem
    declare paga1 float;
    declare paga2 float;
    declare paga3 float;
    declare paga4 float;
    declare paga5 float;
    
    -- obtem valores que somam no montante
    select sum(valor) from compoe_2 into compoe2_soma;
    select sum(valor) from compoe_3 into compoe3_soma;
    select sum(valor) from compoe_4 into compoe4_soma;
    select sum(valor) from compoe_5 into compoe5_soma;
    select sum(valor) from compoe_6 into compoe6_soma;
    -- obtem valores que subtraem no montante
    select sum(valor_aluguel) from area_total into paga1;
    select sum(custo) from material into paga2;
    select sum(valor_horas_trab*horas_totais_trab) from funcionario into paga3;
    select sum(custo) from painelista into paga4;
    select sum(custo) from palestrante into paga5;
    -- define novo montante
    set montante = compoe2_soma + compoe3_soma +  compoe4_soma + compoe5_soma + compoe6_soma - paga1 - paga2 - paga3 - paga4 - paga5;
    update contabilidade set montante_caixa = montante where cod_setor = 5;
end;
delimiter |
create trigger montante_update
after insert on compoe_2
for each row
begin
	declare montante float;
    -- valores que somam
    declare compoe2_soma float;
    declare compoe3_soma float;
    declare compoe4_soma float;
    declare compoe5_soma float;
    declare compoe6_soma float;
    -- valores que subtraem
    declare paga1 float;
    declare paga2 float;
    declare paga3 float;
    declare paga4 float;
    declare paga5 float;
    
    -- obtem valores que somam no montante
    select sum(valor) from compoe_2 into compoe2_soma;
    select sum(valor) from compoe_3 into compoe3_soma;
    select sum(valor) from compoe_4 into compoe4_soma;
    select sum(valor) from compoe_5 into compoe5_soma;
    select sum(valor) from compoe_6 into compoe6_soma;
    -- obtem valores que subtraem no montante
    select sum(valor_aluguel) from area_total into paga1;
    select sum(custo) from material into paga2;
    select sum(valor_horas_trab*horas_totais_trab) from funcionario into paga3;
    select sum(custo) from painelista into paga4;
    select sum(custo) from palestrante into paga5;
    -- define novo montante
    set montante = compoe2_soma + compoe3_soma +  compoe4_soma + compoe5_soma + compoe6_soma - paga1 - paga2 - paga3 - paga4 - paga5;
    update contabilidade set montante_caixa = montante where cod_setor = 5;
end;
|

-- compoe_5 deve ser igual a efetua_2
delimiter |
create trigger insert_compoe5
before insert on compoe_5
for each row
begin
	declare msg varchar(255);
    declare custo_efetua2 float;
    -- veririca valores em efetua_2
    select custo from efetua_2 where id_inscricao = NEW.id_inscricao into custo_efetua2;
    if (custo_efetua2 <> NEW.valor) THEN
		set msg = "ERRO: os valores da efetuação da inscrição e composição da contabilidade referente a inscrição devem ser os mesmos.";
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = msg;
    END IF;
end;
|

delimiter |
create trigger update_compoe5
before update on compoe_5
for each row
begin
	declare msg varchar(255);
    declare custo_efetua2 float;
    -- veririca valores em efetua_2
    select custo from efetua_2 where id_inscricao =	 NEW.id_inscricao into custo_efetua2;
    if (custo_efetua2 <> NEW.valor) THEN
		set msg = "ERRO: os valores da efetuação da inscrição e composição da contabilidade referente a inscrição devem ser os mesmos.";
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = msg;
    END IF;
end;
|

-- atributo CATEGORIA na INSCRICAO deve ser preenchido de acordo com o valor de 
-- EFETUA_2 para aquela 
delimiter |
create trigger inscricao_categoria
after insert on efetua_2
for each row
begin
	declare _categoria varchar(20);
    declare custo float;

    set _categoria = "isento";
    IF (NEW.custo > 0) THEN
		set _categoria = "sem barraca";
    END IF;
    IF (NEW.custo > 270) THEN
		set _categoria = "com barraca";
    END IF;
    
    update inscricao set categoria = _categoria where id_inscricao = NEW.id_inscricao;
end;
|

delimiter |
create trigger inscricao_categoria_2
after update on efetua_2
for each row
begin
	declare _categoria varchar(20);
    declare custo float;

    set _categoria = "isento";
    IF (NEW.custo > 0) THEN
		set _categoria = "sem barraca";
    END IF;
    IF (NEW.custo > 270) THEN
		set _categoria = "com barraca";
    END IF;
    
    update inscricao set categoria = _categoria where id_inscricao = NEW.id_inscricao;
end;
|

-- EXPLICAÇÃO DOS GATILHOS

-- os gatilhos desenvolvidos neste documento sql serão utilizandos
-- junto ao script do construção do schema do banco de dados para 
-- garantir todas as políticas e regras de negócios especificados
-- no modelo entidade relacionamento. Como os atributos derivados
-- e outras situações que pedem comportamentos específicos de inserções
-- e atualizações na base de dados.

-- ATRIBUTOS DERIVADOS

-- IDADE :para o atributo derivado IDADE em PESSOA_FISICA, cria-se um gatilho
-- que obtem antes da inserção a data de nascimento da pessoa e calcula
-- com base no ano atual a diferença entre o ano de nascimento da pessoa
-- e o ano atual, esse valor da diferença é armazenado em uma variável que 
-- terá então seu valor atribuido ao campo idade daquele registro que está sendo
-- incluido. 

-- N_FUNCIONARIOS: para o atributo N_FUNCIONARIOS em SETOR, cria-se um gatilho
-- que conta a quantidade de funcionarios no setor em que o funcionario acabou
-- de ser incluido, armazena então este valor a uma variavel que terá seu conteúdo
-- armazenado na tupla correta da tabela SETOR, ou seja, na tupla correspondente
-- ao setor do funcionario que acabou de ser incluido ou atualizado.

-- MONTANTE_CAIXA: para o atributo MONTANTE_CAIXA em CONTABILIDADE, cria-se um gatilho
-- que obtem todos os valores que somam o montante e subtraem para o calculo do novo
-- montante do caixa da contabilidade, todos esses valores são corretamente somados e 
-- subtraidos na variavel montante e por fim atualizam o campo montante_caixa do setor 
-- de contabilidade, note que o cálculo deve ser feito após a atualização e inserção de qualquer
-- tupla nas tabelas que envolvem soma ou subtração deste montante, o script demonstrado implementa
-- apenas uma vez pois serve apenas de exemplo didático de como deveria ser implementado para um caso.

-- POLÍTICAS DE INSERÇÃO E ATUALIZAÇÃO

-- ID_INSCRICAO E VALOR devem ser iguais em EFETUA_2 e COMPOE_5: isso por que as 2 tabelas são relacionamentos que
-- recebem os mesmos valores das inscrições dos participantes, dessa forma, o valor de inscrição em EFETUA_2, deve
-- ser o mesmo em COMPOE_5, para isso, antes de qualquer atualização ou inserção em COMPOE_5, verifica-se com um
-- gatilho na tabela EFETUA_2, o custo relacionado ao id_inscricao que está sendo inserido ou atualizado em COMPOE_5,
-- se os valores de custo divergirem, é enviado um comando ao SGBD para abortar a inserção ou atualização com uma
-- mensagem de erro personalizada pelo administrador do banco de dados.

-- CATEGORIA em INSCRICAO deve ser a politica de acordo com o custo da INSCRIÇÃO: para isso cria-se um gatilho que busca
-- o valor da inscrição após a inserção ou atualização na tabela EFETUA_2, obtendo o valor, o gatilho verifica com "IFS"
-- o custo da inscrição e finalmente com base neste valor faz uma atualização na tabela INSCRIÇÃO, na tupla onde o ID_INSCRIÇÃO
-- é o mesmo da inserção ou atualização na tabela EFETUA_2.