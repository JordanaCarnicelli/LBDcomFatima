insert into sem_barraca values (24984164666);
insert into sem_barraca values (24984164777);
insert into sem_barraca values (24984164888);
insert into sem_barraca values (24984164999);
insert into sem_barraca values (24984164000);
