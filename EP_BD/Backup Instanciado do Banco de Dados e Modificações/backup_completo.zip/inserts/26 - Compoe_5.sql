insert into compoe_5 values (29,340,5);
insert into compoe_5 values (30,340,5);
insert into compoe_5 values (31,340,5);
insert into compoe_5 values (32,270,5);
insert into compoe_5 values (34,270,5);