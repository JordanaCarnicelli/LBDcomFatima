insert into setor values (1,'0','Texto de atribuições 1',1,0,0,0,0);
insert into setor values (2,'0','Texto de atribuições 2',0,1,0,0,0);
insert into setor values (3,'0','Texto de atribuições 3',0,0,1,0,0);
insert into setor values (4,'0','Texto de atribuições 4',0,0,0,1,0);
insert into setor values (5,'0','Texto de atribuições 5',0,0,0,0,1);