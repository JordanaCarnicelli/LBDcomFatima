insert into produto_alimenticio values (1,'Coxinha','Texto de descrição Coxinha',100,'Lista com ingredientes 1',3);
insert into produto_alimenticio values (2,'Açai','Texto de descrição Açai',90,'Lista com ingredientes 2',9);
insert into produto_alimenticio values (3,'Pastel','Texto de descrição Pastel',80,'Lista com ingredientes 3',7);
insert into produto_alimenticio values (4,'Macarrão','Texto de descrição Macarrão',70,'Lista com ingredientes 4',15);
insert into produto_alimenticio values (5,'Pizza','Texto de descrição Pizza',60,'Lista com ingredientes 5',30);
