insert into ocorrencia values (1,'Roubo','2017-11-19','15:30','Alguém roubou cerca de 5 Notebooks de Campuseiros.','Sanada',24984164555);
insert into ocorrencia values (2,'Acidente','2017-11-19','16:30','Pessoa cardíaca levou um curto circuito ao mexer em aparelho eletrônico, tropeçou e engasgou com o chiclete.','Sanada',15998714555);
insert into ocorrencia values (3,'Acidente','2017-11-20','17:30','Pessoa quebra computador de competição ao perder equilíbrio.','Não sanada',14864586111);
insert into ocorrencia values (4,'Briga','2017-11-20','18:30','2 pessoas se desentendem e começam a brigar.','Sanada',24984164999);
insert into ocorrencia values (5,'Assédio','2017-11-21','19:30','Fulano importuna Beutrana.','Sanada',35798784444);
