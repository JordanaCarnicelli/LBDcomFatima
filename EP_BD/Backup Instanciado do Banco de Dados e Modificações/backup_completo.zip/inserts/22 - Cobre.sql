insert into cobre values (14868895111,5);
insert into cobre values (14868895222,8);
insert into cobre values (14868895333,9);
insert into cobre values (14868895444,1);
insert into cobre values (14868895555,3);
