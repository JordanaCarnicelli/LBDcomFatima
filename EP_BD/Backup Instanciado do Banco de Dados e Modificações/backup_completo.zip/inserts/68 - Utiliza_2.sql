insert into utiliza_2 values (16,'www.campusparty.forum.com');
insert into utiliza_2 values (17,'www.campusparty.com');
insert into utiliza_2 values (18,'www.facebook/CPOfficial');
insert into utiliza_2 values (19,'www.instagram.com/cpofficial');
insert into utiliza_2 values (20,'https://twitter.com/ccxpoficial');