insert into executa values (1,15998714111);
insert into executa values (2,15998714222);
insert into executa values (3,15998714333);
insert into executa values (4,15998714444);
insert into executa values (5,15998714555);