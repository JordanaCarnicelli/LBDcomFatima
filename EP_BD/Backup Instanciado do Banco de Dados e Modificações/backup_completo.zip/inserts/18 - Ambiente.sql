insert into ambiente values ('www.facebook/CPOfficial','Rede Social','Texto de descrição 1');
insert into ambiente values ('www.campusparty.com','Site','Texto de descrição 2');
insert into ambiente values ('www.campusparty.forum.com','Fórum','Texto de descrição 3');
insert into ambiente values ('www.instagram.com/cpofficial','Rede Social','Texto de descrição 4');
insert into ambiente values ('https://twitter.com/ccxpoficial','Rede Social','Texto de descrição 5');