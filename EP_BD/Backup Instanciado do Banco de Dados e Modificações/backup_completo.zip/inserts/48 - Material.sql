insert into material values (1,'Microfone','Aparelho Eletrônico','Texto de descrição 1',30,110,4);
insert into material values (2,'Papel A4','Material de escritório','Texto de descrição 2',5000,0.25,4);
insert into material values (3,'Mesas','Móveis','Texto de descrição 3',50,125,4);
insert into material values (4,'Bancos','Móveis','Texto de descrição 4',100,80,4);
insert into material values (5,'Roteador WiFi','Aparelho Eletrônico','Texto de descrição 5',10,90,4);
insert into material values (6,'Caixa de Som','Aparelho Eletrônico','Texto de descrição 6',10,80,4);