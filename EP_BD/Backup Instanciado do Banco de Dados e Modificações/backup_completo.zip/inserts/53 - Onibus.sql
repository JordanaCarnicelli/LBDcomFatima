insert into onibus values (1,6,'Irizar PB R',50,1);
insert into onibus values (2,7,'Volare W9 ON',51,2);
insert into onibus values (3,8,'Marcopolo V8 ON',52,3);
insert into onibus values (4,9,'Marcopolo Ideale R',53,4);
insert into onibus values (5,10,'Volvo R 21',54,5);