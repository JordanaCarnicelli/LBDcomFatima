insert into expositor values (14535869111,'Apple: Origins','Tecnologias Antigas da Apple','Nostalgia',4176846871111);
insert into expositor values (16548739222,'Microsoft: Revolutions','Novas Tecnologias','Futuro',4176846871222);
insert into expositor values (86431275333,'Nvidia: Unity','Novas Unidades da Marca','Novidades',4176846871333);
insert into expositor values (31286584444,'Enter the VR','Óculos de Realidade Virtual','Experimetação',4176846871444);
insert into expositor values (65498731555,'The Watson Principle','Interação com Watson','Possibilidades',4176846871555);
