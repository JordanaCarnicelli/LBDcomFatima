insert into fornece_2 values (2426270765011,1);
insert into fornece_2 values (7963854505822,2);
insert into fornece_2 values (7318458635733,3);
insert into fornece_2 values (3262144721244,4);
insert into fornece_2 values (1222782878655,5);
