insert into medida values (1,'Texto de descrição 1',21554826111);
insert into medida values (2,'Texto de descrição 2',45612378222);
insert into medida values (3,'Texto de descrição 3',15975614333);
insert into medida values (4,'Texto de descrição 4',35798784444);
insert into medida values (5,'Texto de descrição 5',14535715555);