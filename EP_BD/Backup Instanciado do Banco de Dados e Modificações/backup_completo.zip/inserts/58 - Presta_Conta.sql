insert into presta_conta values (21554826111,1);
insert into presta_conta values (45612378222,1);
insert into presta_conta values (15975614333,1);
insert into presta_conta values (45612378222,4);
insert into presta_conta values (15975614333,5);