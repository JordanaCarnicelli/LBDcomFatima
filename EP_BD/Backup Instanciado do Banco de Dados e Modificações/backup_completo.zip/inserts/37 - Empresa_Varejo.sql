insert into empresa_varejo values (1, 3185860265111,3);
insert into empresa_varejo values (2, 7203236580222,3);
insert into empresa_varejo values (3, 9504818811333,3);
insert into empresa_varejo values (4, 9050752685444,3);
insert into empresa_varejo values (5, 1482115672555,3);