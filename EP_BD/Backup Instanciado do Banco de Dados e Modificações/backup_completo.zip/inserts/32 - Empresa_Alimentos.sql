insert into empresa_alimentos values (2426270765011,26,'C:\Users\Anderson\Desktop\BDcomSarinha\Alvara\2426270765011',3);
insert into empresa_alimentos values (7963854505822,27,'C:\Users\Anderson\Desktop\BDcomSarinha\Alvara\7963854505822',3);
insert into empresa_alimentos values (7318458635733,28,'C:\Users\Anderson\Desktop\BDcomSarinha\Alvara\7318458635733',3);
insert into empresa_alimentos values (3262144721244,29,'C:\Users\Anderson\Desktop\BDcomSarinha\Alvara\3262144721244',3);
insert into empresa_alimentos values (1222782878655,30,'C:\Users\Anderson\Desktop\BDcomSarinha\Alvara\1222782878655',3);