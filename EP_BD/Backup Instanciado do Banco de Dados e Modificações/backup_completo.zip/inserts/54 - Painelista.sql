insert into painelista values (14864586111,'IA vai dominar o mundo?','Tecnologia',650,5);
insert into painelista values (14864586222,'Como sobreviver ao ataque zombie','Variedades',690,5);
insert into painelista values (14864586333,'Microtransações: o declinio dos games','Entretenimento',590,5);
insert into painelista values (14864586444,'Kubrick: cada frame uma pintura.','Entretenimento',680,5);
insert into painelista values (14864586555,'Iniciando sua propria empresa','Empreendedorismo',540,5);