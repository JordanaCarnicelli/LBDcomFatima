insert into telefone values (1,54654654);
insert into telefone values (2,58926461);
insert into telefone values (3,51321365);
insert into telefone values (4,51659789);
insert into telefone values (5,53598713);
