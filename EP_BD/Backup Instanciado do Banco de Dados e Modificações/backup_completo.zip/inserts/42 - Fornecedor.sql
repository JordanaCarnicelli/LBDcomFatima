insert into fornecedor values (6191831709652,3,5);
insert into fornecedor values (3259265956543,3,5);
insert into fornecedor values (6325255392663,3,5);
insert into fornecedor values (5047119538993,3,5);
insert into fornecedor values (9199421953290,3,5);