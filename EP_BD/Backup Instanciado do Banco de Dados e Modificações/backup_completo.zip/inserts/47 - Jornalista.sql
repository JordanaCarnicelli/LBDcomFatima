insert into jornalista values (14868895111,836531,'Ciência',5196586873111);
insert into jornalista values (14868895222,643763,'Tecnologia',5196586873222);
insert into jornalista values (14868895333,562031,'Games',5196586873333);
insert into jornalista values (14868895444,919853,'Empreendedorismo',5196586873444);
insert into jornalista values (14868895555,418992,'Economia',5196586873555);