insert into caravana values (1,'Caravana do Norte','Acre',35);
insert into caravana values (2,'Caravana do Sudeste','São Paulo',32);
insert into caravana values (3,'Caravana do Sul','Rio Grande do Sul',36);
insert into caravana values (4,'Caravana do Nordeste','Bahia',29);
insert into caravana values (5,'Caravana do Centro Oeste','Brasília',33);