insert into relatorio_oficial values ('Delegado de Polícia Militar','Todos os conteúdos do relatório que será entregue ao Delegado de Polícia Militar.');
insert into relatorio_oficial values ('Prefeito do Município','Todos o conteúdo do relatório que será entregue ao Prefeito do Município.');
insert into relatorio_oficial values ('Diretor-Presidente da Vigilância Sanitária','Todos o conteúdo do relatório que será entregue ao Diretor-Presidente da Vigilância Sanitária.');
insert into relatorio_oficial values ('Delegado de Polícia Civil','Todos o conteúdo do relatório que será entregue ao Delegado de Polícia Civil.');
insert into relatorio_oficial values ('Reitor da Universidade','Todos o conteúdo do relatório que será entregue ao Reitor da Universidade.');
