insert into sana values (1,1);
insert into sana values (2,2);
insert into sana values (3,3);
insert into sana values (4,4);
insert into sana values (5,5);