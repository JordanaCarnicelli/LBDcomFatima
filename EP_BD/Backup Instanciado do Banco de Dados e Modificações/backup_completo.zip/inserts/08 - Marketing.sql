insert into marketing values (3, 6);
