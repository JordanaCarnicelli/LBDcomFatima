insert into recebe_1 values (14868895222,1);
insert into recebe_1 values (14868895333,1);
insert into recebe_1 values (14868895444,2);
insert into recebe_1 values (14868895555,4);
insert into recebe_1 values (14535869111,4);
