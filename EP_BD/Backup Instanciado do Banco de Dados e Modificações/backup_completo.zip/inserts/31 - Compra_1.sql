insert into compra_1 values (24984164111,1);
insert into compra_1 values (24984164222,2);
insert into compra_1 values (24984164333,3);
insert into compra_1 values (24984164444,4);
insert into compra_1 values (24984164555,5);