insert into gerente_setorial values (1,76150293111);
insert into gerente_setorial values (2,76150293222);
insert into gerente_setorial values (3,76150293333);
insert into gerente_setorial values (4,76150293444);
insert into gerente_setorial values (5,76150293555);