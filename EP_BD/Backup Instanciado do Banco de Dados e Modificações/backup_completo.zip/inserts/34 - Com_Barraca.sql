insert into com_barraca values (6,24984164111);
insert into com_barraca values (7,24984164222);
insert into com_barraca values (8,24984164333);
insert into com_barraca values (9,24984164444);
insert into com_barraca values (10,24984164555);