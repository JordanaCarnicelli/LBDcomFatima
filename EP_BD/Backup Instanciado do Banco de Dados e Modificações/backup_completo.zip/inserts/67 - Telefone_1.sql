insert into telefone_1 values (15998714444,52369874);
insert into telefone_1 values (15998714555,57893214);
insert into telefone_1 values (16548739222,59632148);
insert into telefone_1 values (21554826111,59876321);
insert into telefone_1 values (24984164000,51347963);