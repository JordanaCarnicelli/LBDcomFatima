insert into produto values (1,'Camisa Logan','Vestuário','Texto de descrição 1',55,50);
insert into produto values (2,'Caneca inútil','Louça','Texto de descrição 2',40,48);
insert into produto values (3,'Zombicide','Boardgame','Texto de descrição 3',100,340);
insert into produto values (4,'Sensores térmicos','Eletrônico','Texto de descrição 4',30,15);
insert into produto values (5,'Óculos de sol','Acessório','Texto de descrição 5',85,200);