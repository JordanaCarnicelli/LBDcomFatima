insert into administrador_geral values (21554826111,'Texto de responsabilidades 1');
insert into administrador_geral values (45612378222,'Texto de responsabilidades 2');
insert into administrador_geral values (15975614333,'Texto de responsabilidades 3');
insert into administrador_geral values (35798784444,'Texto de responsabilidades 4');
insert into administrador_geral values (14535715555,'Texto de responsabilidades 5');