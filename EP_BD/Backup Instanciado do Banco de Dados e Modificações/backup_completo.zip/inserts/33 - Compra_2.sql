insert into compra_2 values (16548739222, 1);
insert into compra_2 values (21554826111, 2);
insert into compra_2 values (24984164000,3);
insert into compra_2 values (24984164111,4);
insert into compra_2 values (24984164222,5);