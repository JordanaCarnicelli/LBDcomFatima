insert into virtual values (16);
insert into virtual values (17);
insert into virtual values (18);
insert into virtual values (19);
insert into virtual values (20);