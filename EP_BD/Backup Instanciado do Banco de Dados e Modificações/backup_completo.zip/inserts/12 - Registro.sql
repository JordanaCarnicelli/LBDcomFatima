insert into registro values (5,1,'Entrada','2017-11-17',2500);
insert into registro values (5,2,'Entrada','2017-11-17',1500);
insert into registro values (5,3,'Saída','2017-11-18',3000);
insert into registro values (5,4,'Saída','2017-11-18',5000);
insert into registro values (5,5,'Saída','2017-11-18',560);