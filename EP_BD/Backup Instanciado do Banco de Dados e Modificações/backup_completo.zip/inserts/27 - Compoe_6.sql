insert into compoe_6 values (2426270765011,2500,5);
insert into compoe_6 values (7963854505822,2500,5);
insert into compoe_6 values (7318458635733,2500,5);
insert into compoe_6 values (3262144721244,2500,5);
insert into compoe_6 values (1222782878655,2500,5);