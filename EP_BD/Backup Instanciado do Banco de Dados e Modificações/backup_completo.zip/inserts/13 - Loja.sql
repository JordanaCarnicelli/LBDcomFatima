insert into loja values (1, 11, 0);
insert into loja values (2, 12, 0);
insert into loja values (3, 13, 0);
insert into loja values (4, 14, 0);
insert into loja values (5, 15, 0);
insert into loja values (6, 36, 0);