insert into recurso_humano values (10641897111,'Segurança',22,32,2,6191831709652);
insert into recurso_humano values (10641897222,'Segurança',22,32,2,6191831709652);
insert into recurso_humano values (10641897333,'Limpeza',20,32,2,3259265956543);
insert into recurso_humano values (10641897444,'Limpeza',20,32,2,3259265956543);
insert into recurso_humano values (10641897555,'Limpeza',20,32,2,3259265956543);