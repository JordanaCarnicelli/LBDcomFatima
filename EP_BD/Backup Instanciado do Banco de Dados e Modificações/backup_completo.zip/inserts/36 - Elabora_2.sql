insert into elabora_2 values (21554826111,'Delegado de Polícia Militar');
insert into elabora_2 values (21554826111,'Prefeito do Município');
insert into elabora_2 values (45612378222,'Delegado de Polícia Militar');
insert into elabora_2 values (45612378222,'Diretor-Presidente da Vigilância Sanitária');
insert into elabora_2 values (45612378222,'Delegado de Polícia Civil');