insert into area_total values ('R. Maria Curupaiti',441,'Vila Ester','São Paulo',02452001,128,5000,3);
insert into area_total values ('R. Bragança Paulista',1281,'Vila Cruzeiro','São Paulo',04727000,158,6000,3);
insert into area_total values ('Av. Francisco Matarazzo',694,'Água Branca','São Paulo',05001000,145,7000,3);
insert into area_total values ('Av. Auro Soares de Moura Andrade',664,'Barra Funda','São Paulo',01156001,162,8000,3);
insert into area_total values ('R. Gumercindo Saraiva',54,'Pinheiros','São Paulo',01449070,129,5500,3);