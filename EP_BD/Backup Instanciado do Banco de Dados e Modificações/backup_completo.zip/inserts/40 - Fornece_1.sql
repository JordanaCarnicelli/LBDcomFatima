insert into fornece_1 values (6325255392663,1);
insert into fornece_1 values (6325255392663,6);
insert into fornece_1 values (5047119538993,3);
insert into fornece_1 values (5047119538993,4);
insert into fornece_1 values (9199421953290,5);