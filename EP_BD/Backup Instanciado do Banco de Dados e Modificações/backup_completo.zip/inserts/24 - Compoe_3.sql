insert into compoe_3 values (3185860265111,2500,5);
insert into compoe_3 values (7203236580222,2500,5);
insert into compoe_3 values (9504818811333,2500,5);
insert into compoe_3 values (9050752685444,2500,5);
insert into compoe_3 values (1482115672555,2500,5);
