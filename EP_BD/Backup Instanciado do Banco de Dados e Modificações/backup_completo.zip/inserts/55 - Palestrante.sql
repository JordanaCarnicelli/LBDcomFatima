insert into palestrante values (41684194111,'Hacking: a arte do desbloqueio','Tecnologia',580,5);
insert into palestrante values (41684194222,'2019: Xavier e o fim do mundo','Variedades',640,5);
insert into palestrante values (41684194333,'IA: criacionismo moderno','Tecnologia',620,5);
insert into palestrante values (41684194444,'Como projetar a sua ideia revolucionária','Empreendedorismo',570,5);
insert into palestrante values (41684194555,'Cidade dos drones','Tecnologia',535,5);
insert into palestrante values (41684194666,'Como se tornar um ninja em BD','Computação',4500,5);