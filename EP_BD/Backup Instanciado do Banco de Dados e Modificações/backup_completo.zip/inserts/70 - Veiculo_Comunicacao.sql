insert into VEICULO_COMUNICACAO values (5196586873111,'Jornal Impresso');
insert into VEICULO_COMUNICACAO values (5196586873222,'Televisão');
insert into VEICULO_COMUNICACAO values (5196586873333,'Youtube');
insert into VEICULO_COMUNICACAO values (5196586873444,'Rádio');
insert into VEICULO_COMUNICACAO values (5196586873555,'Blog');